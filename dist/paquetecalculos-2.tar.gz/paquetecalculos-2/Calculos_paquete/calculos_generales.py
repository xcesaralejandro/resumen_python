# ESTO ES UN MODULO :)
def sumar (n1,n2):
    print("Resultado de la suma: ", n1 + n2)

def restar (n1,n2):
    print("Resultado de la resta: ", n1 - n2)

def multiplicar (n1,n2):
    print("Resultado de la multiplicacion: ", n1 * n2)