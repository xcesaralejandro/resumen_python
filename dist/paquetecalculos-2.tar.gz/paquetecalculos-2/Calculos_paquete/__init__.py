# PAQUETES
# Son directorios donde se almacenarán N modulos relacionados entre si.
# Para crear un paquete hay que crear una carpeta y tener dentro un archivo llamado __init__.py
# Un paquete puede tener N sub-paquetes dentro y el requisito es el mismo que se menciona en las
# lineas de arriba.
